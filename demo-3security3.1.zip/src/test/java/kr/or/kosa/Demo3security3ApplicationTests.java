package kr.or.kosa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo3security3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
