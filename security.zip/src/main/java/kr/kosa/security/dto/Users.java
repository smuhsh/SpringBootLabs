package kr.kosa.security.dto;

import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class Users {
    private  int userNo;
    private String userId;
    private String userPw;
    private String name;
    private String email;
    private Date regDate;
    private Date updDate;

    //권한 목록
    List<UserAuth> authList;

    private int enabled;

}
